float **allocFloatMatrix(int columns, int rows);

char **allocCharMatrix(int columns, int rows);

void freeMatrix(void *matrix);